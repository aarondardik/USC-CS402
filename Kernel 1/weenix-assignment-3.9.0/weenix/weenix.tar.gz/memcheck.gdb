set kernel memcheck on
